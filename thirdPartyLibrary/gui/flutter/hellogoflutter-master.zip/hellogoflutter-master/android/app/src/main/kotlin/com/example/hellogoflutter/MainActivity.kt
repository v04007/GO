package com.example.hellogoflutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
