# hellogoflutter
a go flutter example

## 简易教程

[go-flutter开发桌面应用（一）第一个桌面应用](https://zhuanlan.zhihu.com/p/254728424)

[go-flutter开发桌面应用（二） 创建go-flutter插件](https://zhuanlan.zhihu.com/p/254953560)

[go-flutter开发桌面应用（三） go-flutter插件中参数的传递 基本类型](https://zhuanlan.zhihu.com/p/255032739)

[go-flutter开发桌面应用（四） go-flutter插件中参数的传递 struct转map](https://zhuanlan.zhihu.com/p/337252450)

[go-flutter开发桌面应用（五） go-flutter的Go端向Dart端发送消息](https://zhuanlan.zhihu.com/p/339122863)
